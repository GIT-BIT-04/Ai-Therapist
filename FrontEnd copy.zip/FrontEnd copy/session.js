document.getElementById("messageForm").addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent form submission

    const userInput = document.getElementById("userInput").value;
    if (!userInput.trim()) return; // Do nothing if input is empty

    // Display the user's message in the chatbox
    const chatBox = document.getElementById("chatBox");
    const userMessage = document.createElement("div");
    userMessage.classList.add("message", "user-message");
    userMessage.textContent = userInput;
    chatBox.appendChild(userMessage);

    // Scroll to the bottom of the chatbox
    chatBox.scrollTop = chatBox.scrollHeight;

    // Clear the input field
    document.getElementById("userInput").value = "";

    // Send user input to the backend
    try {
        const response = await fetch("/process", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ message: userInput }),
        });

        if (response.ok) {
            const data = await response.json();

            // Create a container for the AI's response
            const aiMessageContainer = document.createElement("div");
            aiMessageContainer.classList.add("message", "ai-message");

            // Add detected emotion
            const emotionHeader = document.createElement("h4");
            emotionHeader.textContent = "Detected Emotion:";
            aiMessageContainer.appendChild(emotionHeader);

            const emotionText = document.createElement("p");
            emotionText.textContent = data.emotion || "Unknown";
            aiMessageContainer.appendChild(emotionText);

            // Add recommendations
            const recommendationsHeader = document.createElement("h4");
            recommendationsHeader.textContent = "Recommended Therapies:";
            aiMessageContainer.appendChild(recommendationsHeader);

            const recommendationsList = document.createElement("ul");
            (data.recommendations || []).forEach((rec) => {
                const listItem = document.createElement("li");
                listItem.textContent = rec;
                recommendationsList.appendChild(listItem);
            });

            aiMessageContainer.appendChild(recommendationsList);

            // Add the AI's response container to the chatbox
            chatBox.appendChild(aiMessageContainer);

            // Scroll to the bottom of the chatbox
            chatBox.scrollTop = chatBox.scrollHeight;
        } else {
            console.error("Failed to fetch response from backend.");
        }
    } catch (error) {
        console.error("Error communicating with the backend:", error);
    }
});
