// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB11wm6S-9F_usrNZITkiMArlkG2dZnBfI",
  authDomain: "ai-therapist-6050e.firebaseapp.com",
  projectId: "ai-therapist-6050e",
  storageBucket: "ai-therapist-6050e.appspot.com",
  messagingSenderId: "1084132506506",
  appId: "1:1084132506506:web:5056d860bd73e3e90fa673"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

function showMessage(message, divId) {
  const messageDiv = document.getElementById(divId);
  messageDiv.style.display = "block";
  messageDiv.innerHTML = message;
  messageDiv.style.opacity = 1;
  setTimeout(function() {
    messageDiv.style.opacity = 0;
  }, 5000);
}

const loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit', (event) => {
  event.preventDefault();  
  const email = document.getElementById('email').value;  
  const password = document.getElementById('password').value;  
  const auth = getAuth();
  
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      showMessage('Login successful', 'loginMessage');
      window.location.href = 'home.html';  // Redirect to home after successful login
    })
    .catch((error) => {
      const errorCode = error.code;
      if (errorCode === 'auth/user-not-found') {
        showMessage('User not found', 'loginMessage');
      } else if (errorCode === 'auth/wrong-password') {
        showMessage('Incorrect password', 'loginMessage');
      } else {
        showMessage('Error logging in', 'loginMessage');
      }
    });
});
