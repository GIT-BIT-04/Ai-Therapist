document.getElementById("signupForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission
  
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const errorMessage = document.getElementById("error-message");
  
    // Clear previous error message
    errorMessage.textContent = '';
  
    // Simple validation
    if (password !== confirmPassword) {
      errorMessage.textContent = "Passwords do not match.";
      return;
    }
  
    // Simulate form submission or send data to server
    alert("Signup successful!\nName: " + name + "\nEmail: " + email);
  
    // Optionally, clear form fields
    document.getElementById("signupForm").reset();
  });
  