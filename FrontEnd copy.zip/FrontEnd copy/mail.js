// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import {getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";
import {getFirestore, setDoc, doc} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB11wm6S-9F_usrNZITkiMArlkG2dZnBfI",
  authDomain: "ai-therapist-6050e.firebaseapp.com",
  projectId: "ai-therapist-6050e",
  storageBucket: "ai-therapist-6050e.appspot.com",
  messagingSenderId: "1084132506506",
  appId: "1:1084132506506:web:5056d860bd73e3e90fa673"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);  

function showMessage(message, divId) {
  var messageDiv = document.getElementById(divId);
  messageDiv.style.display = "block";
  messageDiv.innerHTML = message;
  messageDiv.style.opacity = 1;
  setTimeout(function() {
    messageDiv.style.opacity = 0;
  }, 5000);
}

const signUp = document.getElementById('submitSignUp'); 
signUp.addEventListener('click', (event) => {  
  event.preventDefault();  
  const name = document.getElementById('name').value;  
  const email = document.getElementById('email').value;  
  const password = document.getElementById('password').value; 
  const confirmPassword = document.getElementById('confirmPassword').value;  
  
  // Check if password and confirmPassword match
  if (password !== confirmPassword) {
    showMessage('Passwords do not match', 'signUpMessage');
    return;
  }

  const auth = getAuth();
  const db = getFirestore();

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      const userData = {
        name: name,
        email: email,
        password: password
      };
      showMessage('Account Created Successfully', 'signUpMessage');
      
      // Save user data to Firestore
      const docRef = doc(db, "users", user.uid);
      setDoc(docRef, userData)
        .then(() => {
          window.location.href = 'login.html';
        })
        .catch((error) => {
          console.error("Error writing document", error);
        });
    })
    .catch((error) => {
      const errorCode = error.code; 
      if (errorCode === 'auth/email-already-in-use') {
        showMessage('Email already in use', 'signUpMessage'); 
      } else {
        showMessage('Error creating account', 'signUpMessage');
      }
    });
});
