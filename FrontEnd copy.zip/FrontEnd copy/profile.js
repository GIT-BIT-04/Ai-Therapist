import { auth, db } from './profile.js';
import { updateProfile, updatePassword, reauthenticateWithCredential, EmailAuthProvider, signOut, deleteUser } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';
import { doc, getDoc, updateDoc, setDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';

// Load profile information when the page loads
window.addEventListener('DOMContentLoaded', async () => {
  const user = auth.currentUser;

  if (user) {
    const userDoc = doc(db, 'users', user.uid);
    const userProfile = await getDoc(userDoc);
    
    if (userProfile.exists()) {
      document.getElementById('name').value = userProfile.data().name;
      document.getElementById('email').value = user.email;  // Read only
    }
  }
});

// Update Profile Information
document.getElementById('profileForm').addEventListener('submit', async function(event) {
  event.preventDefault();
  
  const name = document.getElementById('name').value;
  const user = auth.currentUser;
  
  if (user) {
    // Update Firebase Auth profile
    await updateProfile(user, { displayName: name });
    
    // Update Firestore user document
    const userDoc = doc(db, 'users', user.uid);
    await updateDoc(userDoc, { name });

    alert('Profile Updated Successfully!');
  } else {
    alert('No user is logged in.');
  }
});

// Update Password
document.getElementById('passwordForm').addEventListener('submit', async function(event) {
  event.preventDefault();
  
  const currentPassword = document.getElementById('currentPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  
  if (newPassword !== confirmPassword) {
    alert('New passwords do not match.');
    return;
  }
  
  const user = auth.currentUser;
  
  if (user) {
    const email = user.email;
    const credential = EmailAuthProvider.credential(email, currentPassword);
    
    // Reauthenticate user
    await reauthenticateWithCredential(user, credential)
      .then(async () => {
        // Update password
        await updatePassword(user, newPassword);
        alert('Password Updated Successfully!');
      })
      .catch((error) => {
        alert('Current password is incorrect.');
      });
  } else {
    alert('No user is logged in.');
  }
});

// Update Notification Preferences
document.getElementById('notificationsForm').addEventListener('submit', async function(event) {
  event.preventDefault();
  
  const emailNotifications = document.getElementById('emailNotifications').checked;
  const pushNotifications = document.getElementById('pushNotifications').checked;

  const user = auth.currentUser;
  
  if (user) {
    const userDoc = doc(db, 'users', user.uid);
    await updateDoc(userDoc, {
      emailNotifications: emailNotifications,
      pushNotifications: pushNotifications
    });

    alert('Notification Preferences Updated!');
  }
});

// Delete Account
document.getElementById('deleteAccount').addEventListener('click', async function() {
  if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
    const user = auth.currentUser;
    
    if (user) {
      // Delete account from authentication
      await deleteUser(user);
      
      // Optionally, delete user data from Firestore
      await db.collection('users').doc(user.uid).delete();
      
      alert('Account Deleted.');
      window.location.href = 'signup.html';
    }
  }
});

// Sign Out (if needed on profile page)
document.getElementById('signOutButton').addEventListener('click', async function() {
  await signOut(auth);
  alert('Signed out.');
  window.location.href = 'login.html';
});
