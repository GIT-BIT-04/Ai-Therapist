 // Your Firebase config
 const firebaseConfig = {
    apiKey: "AIzaSyB11wm6S-9F_usrNZITkiMArlkG2dZnBfI",
    authDomain: "ai-therapist-6050e.firebaseapp.com",
    projectId: "ai-therapist-6050e",
    storageBucket: "ai-therapist-6050e.appspot.com",
    messagingSenderId: "1084132506506",
    appId: "1:1084132506506:web:5056d860bd73e3e90fa673"
  };

  // Initialize Firebase
  const app = firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
  const db = firebase.firestore();

  // Retrieve and display user's name
  auth.onAuthStateChanged(user => {
    if (user) {
      const userId = user.uid;

      // Assuming the user's name is stored in Firestore in a "users" collection
      db.collection('users').doc(userId).get().then(doc => {
        if (doc.exists) {
          const userName = doc.data().name; // Assuming the field for name is 'name'
          document.getElementById('user-name').textContent = `Welcome Back, ${userName}`;
        } else {
          console.log('No such document!');
        }
      }).catch(error => {
        console.log('Error getting document:', error);
      });
    }
  });