// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import {getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";
import {getFirestore, setDoc, doc} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB11wm6S-9F_usrNZITkiMArlkG2dZnBfI",
  authDomain: "ai-therapist-6050e.firebaseapp.com",
  projectId: "ai-therapist-6050e",
  storageBucket: "ai-therapist-6050e.appspot.com",
  messagingSenderId: "1084132506506",
  appId: "1:1084132506506:web:5056d860bd73e3e90fa673"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export auth and firestore
export const auth = getAuth(app);
export const db = getFirestore(app);

